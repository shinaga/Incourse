package com.example.incourse;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class Course extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent=getIntent();
        int checkNum=intent.getIntExtra("language",0);
        if(checkNum==1)setContentView(R.layout.activity_coursekor);
        if(checkNum==0)setContentView(R.layout.activity_course);

    }
}