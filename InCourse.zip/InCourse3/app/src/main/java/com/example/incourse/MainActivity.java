package com.example.incourse;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ActionBar;
import android.content.Context;
import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.view.GestureDetector;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.internal.TextDrawableHelper;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    ArrayList<ImageView> seoulList1=new ArrayList<ImageView>();
    ArrayList<ImageView> seoulList2=new ArrayList<ImageView>();
    ArrayList<ImageView> seoulList3=new ArrayList<ImageView>();
    ArrayList<ImageView> busanList1=new ArrayList<ImageView>();
    ArrayList<ImageView> busanList2=new ArrayList<ImageView>();
    ArrayList<ImageView> busanList3=new ArrayList<ImageView>();
    ArrayList<ImageView> gyeongjuList1=new ArrayList<ImageView>();
    ArrayList<ImageView> gyeongjuList2=new ArrayList<ImageView>();
    ArrayList<ImageView> gyeongjuList3=new ArrayList<ImageView>();

    RadioButton seoulButton1,seoulButton2,seoulButton3,
            busanButton1,busanButton2,busanButton3,
            gyeongjuButton1,gyeongjuButton2,gyeongjuButton3;
    Intent intent;
    TextView text1;
    //여기서부터
    private List<String> list;          // 데이
    private EditText editSearch;        // 검색어를 입력할 Input 창터를 넣은 리스트변수
    private ListView listView;          // 검색을 보여줄 리스트변수
    private com.example.incourse.SearchAdapter adapter;      // 리스트뷰에 연결할 아답터
    private ArrayList<String> arraylist;
    private List<String> stringList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageSetting();//이미지 등록
        imgOptimi();//좌우 크기 맞추기
        buttonSetting();//버튼 등록gyeongjuButton1=findViewById(R.id.gyeongjuButton1);
        firstButton();//처음으로 눌러질 버튼
        {
            seoulButton1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    for(int i=0;i<seoulList1.size();i++){
                        seoulList1.get(0).setVisibility(View.VISIBLE);
                    }
                    for(int i=0;i<seoulList2.size();i++){
                        seoulList2.get(0).setVisibility(View.GONE);
                    }
                    for(int i=0;i<seoulList3.size();i++){
                        seoulList3.get(0).setVisibility(View.GONE);
                    }
                }
            });
            seoulButton2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    for(int i=0;i<seoulList1.size();i++){
                        seoulList1.get(0).setVisibility(View.GONE);
                    }
                    for(int i=0;i<seoulList2.size();i++){
                        seoulList2.get(0).setVisibility(View.VISIBLE);
                    }
                    for(int i=0;i<seoulList3.size();i++){
                        seoulList3.get(0).setVisibility(View.GONE);
                    }
                }
            });
            seoulButton3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    for(int i=0;i<seoulList1.size();i++){
                        seoulList1.get(0).setVisibility(View.GONE);
                    }
                    for(int i=0;i<seoulList2.size();i++){
                        seoulList2.get(0).setVisibility(View.GONE);
                    }
                    for(int i=0;i<seoulList3.size();i++){
                        seoulList3.get(0).setVisibility(View.VISIBLE);
                    }
                }
            });
        }//라디오 버튼 클릭 이벤트 등록
        {
            busanList1.get(0).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    intent = new Intent(getApplicationContext(), Busan1_1.class);
                    startActivity(intent);
                }
            });
            gyeongjuList3.get(0).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    intent = new Intent(getApplicationContext(), Gyeoungju3_1.class);
                    startActivity(intent);
                }
            });
        }//이미지 클릭 이벤트 등록

        editSearch = (EditText) findViewById(R.id.editSearch);
        listView = (ListView) findViewById(R.id.listView);
        {
            //intent=getIntent();
            //text1 = findViewById(R.id.text1);
            //text1.setText(intent.getStringExtra("local"));
            //if(text1.getText()==""){
            //text1.setText("VVV");
            //}
        }//intent 받아오기 테스트코드

        {
            // intent = new Intent(getApplicationContext(), TravelActivity.class);
            //imgSeoul1.setOnClickListener(new View.OnClickListener() {
            //    @Override
            //    public void onClick(View view) {
            //        intent.putExtra("local", "SSS");
            //        startActivity(intent);
            //    }
            //});
        }//intent 보내기 테스트코드

        //여기서부터 검색화면 관련 코드


        // 리스트를 생성한다.
        list = new ArrayList<String>();
        stringList = new ArrayList<String>();
        // 검색에 사용할 데이터을 미리 저장한다.
        settingList();

        // 리스트의 모든 데이터를 arraylist에 복사한다.// list 복사본을 만든다.
        arraylist = new ArrayList<String>();
        arraylist.addAll(list);

        // 리스트에 연동될 아답터를 생성한다.
        adapter = new com.example.incourse.SearchAdapter(list, this);

        // 리스트뷰에 아답터를 연결한다.
        listView.setAdapter(adapter);

        // input창에 검색어를 입력시 "addTextChangedListener" 이벤트 리스너를 정의한다.
        editSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                // input창에 문자를 입력할때마다 호출된다.
                // search 메소드를 호출한다.
                String text = editSearch.getText().toString();
                search(text);
            }
        });//텍스트창의 입력이 체인지 됐을때 발생하는 이벤트 리스너

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ListView item = (ListView) parent.getItemAtPosition(position);

               Toast.makeText(getApplicationContext(),stringList.get(position),Toast.LENGTH_SHORT).show();
            }
        });//리스트뷰 클릭시 이동 (곧 구현 예정)

    }


    // 검색을 수행하는 메소드
    public void search(String charText) {
        listView.setVisibility(View.GONE); //입력시 눈으로 볼 수 있게함
        stringList.clear();//입력시 초기화

        // 문자 입력시마다 리스트를 지우고 새로 뿌려준다.
        list.clear();


        // 문자 입력이 없을때는 모든 데이터를 보여준다.
        if (charText.length() == 0) {
            list.addAll(arraylist);
            listView.setVisibility(View.GONE);//입력 없을시 눈으로 볼 수 없게함
        }

        // 문자 입력을 할때..
        else
        {
            // 리스트의 모든 데이터를 검색한다.
            for(int i = 0;i < arraylist.size(); i++)
            {
                // arraylist의 모든 데이터에 입력받은 단어(charText)가 포함되어 있으면 true를 반환한다.
                if (arraylist.get(i).toLowerCase().contains(charText))
                {
                    // 검색된 데이터를 리스트에 추가한다.
                    list.add(arraylist.get(i));
                    stringList.add(arraylist.get(i));
                    listView.setVisibility(View.VISIBLE);
                }
            }
        }

        // 리스트 데이터가 변경되었으므로 아답터를 갱신하여 검색된 데이터를 화면에 보여준다.
        adapter.notifyDataSetChanged();
    }
    private void imageSetting(){
        seoulList1.add((ImageView)findViewById(R.id.seoulImg1_1));
        seoulList2.add((ImageView)findViewById(R.id.seoulImg2_1));
        seoulList3.add((ImageView)findViewById(R.id.seoulImg3_1));
        busanList1.add((ImageView)findViewById(R.id.busanImg1_1));
        busanList2.add((ImageView)findViewById(R.id.busanImg2_1));
        busanList3.add((ImageView)findViewById(R.id.busanImg3_1));
        gyeongjuList1.add((ImageView)findViewById(R.id.gyeongjuImg1_1));
        gyeongjuList2.add((ImageView)findViewById(R.id.gyeongjuImg2_1));
        gyeongjuList3.add((ImageView)findViewById(R.id.gyeongjuImg3_1));
    }
    private void imgOptimi() {
        DisplayMetrics metrics = new DisplayMetrics();
        WindowManager windowManager = (WindowManager) getApplicationContext().getSystemService(Context.WINDOW_SERVICE);
        windowManager.getDefaultDisplay().getMetrics(metrics);
        LayoutParams params = (LayoutParams) seoulList1.get(0).getLayoutParams();
        params.width = metrics.widthPixels / 3;
        for(int i=0;i<seoulList1.size();i++){
            seoulList1.get(i).setLayoutParams(params);
        }
        for(int i=0;i<seoulList2.size();i++){
            seoulList2.get(i).setLayoutParams(params);
        }
        for(int i=0;i<seoulList3.size();i++){
            seoulList3.get(i).setLayoutParams(params);
        }
        for(int i=0;i<busanList1.size();i++){
            busanList1.get(i).setLayoutParams(params);
        }
        for(int i=0;i<busanList2.size();i++){
            busanList2.get(i).setLayoutParams(params);
        }
        for(int i=0;i<busanList3.size();i++){
            busanList3.get(i).setLayoutParams(params);
        }
        for(int i=0;i<gyeongjuList1.size();i++){
            gyeongjuList1.get(i).setLayoutParams(params);
        }
        for(int i=0;i<gyeongjuList2.size();i++){
            gyeongjuList2.get(i).setLayoutParams(params);
        }
        for(int i=0;i<gyeongjuList3.size();i++){
            gyeongjuList3.get(i).setLayoutParams(params);
        }
    }
    private void buttonSetting() {
        seoulButton1=findViewById(R.id.seoulButton1);
        seoulButton2=findViewById(R.id.seoulButton2);
        seoulButton3=findViewById(R.id.seoulButton3);
        busanButton1=findViewById(R.id.busanButton1);
        busanButton2=findViewById(R.id.busanButton2);
        busanButton3=findViewById(R.id.busanButton3);
        gyeongjuButton1=findViewById(R.id.gyeongjuButton1);
        gyeongjuButton2=findViewById(R.id.gyeongjuButton2);
        gyeongjuButton3=findViewById(R.id.gyeongjuButton3);
    }
    private void firstButton() {
        seoulButton1.setChecked(true);
        for(int i=0;i<seoulList1.size();i++){
            seoulList1.get(i).setVisibility(View.VISIBLE);
        }
    }
    // 검색에 사용될 데이터를 리스트에 추가한다.
    private void settingList(){
        list.add("서울");
        list.add("부산");
        list.add("전라도");
        list.add("강원");
        list.add("경주");
        list.add("제주도");
    }
}

