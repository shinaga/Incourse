package com.example.incourse;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

public class Jeju1_1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jeju1_1);

        Intent intent=getIntent();
        int checkNum=intent.getIntExtra("language",0);
        if(checkNum==0)setContentView(R.layout.activity_jeju1_1);
        if(checkNum==1)setContentView(R.layout.activity_jeju1_1kor);
    }
}