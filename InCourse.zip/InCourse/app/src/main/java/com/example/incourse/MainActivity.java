package com.example.incourse;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ActionBar;
import android.content.Context;
import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.view.GestureDetector;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.internal.TextDrawableHelper;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    ArrayList<ImageView> seoulList1=new ArrayList<ImageView>();
    ArrayList<ImageView> seoulList2=new ArrayList<ImageView>();
    ArrayList<ImageView> seoulList3=new ArrayList<ImageView>();

    ArrayList<ImageView> busanList1=new ArrayList<ImageView>();
    ArrayList<ImageView> busanList2=new ArrayList<ImageView>();
    ArrayList<ImageView> busanList3=new ArrayList<ImageView>();

    ArrayList<ImageView> gyeongjuList1=new ArrayList<ImageView>();
    ArrayList<ImageView> gyeongjuList2=new ArrayList<ImageView>();
    ArrayList<ImageView> gyeongjuList3=new ArrayList<ImageView>();

    ArrayList<ImageView> jejuList1=new ArrayList<ImageView>();
    ArrayList<ImageView> jejuList2=new ArrayList<ImageView>();
    ArrayList<ImageView> jejuList3=new ArrayList<ImageView>();

    ArrayList<ImageView> gangwonList1=new ArrayList<ImageView>();
    ArrayList<ImageView> gangwonList2=new ArrayList<ImageView>();
    ArrayList<ImageView> gangwonList3=new ArrayList<ImageView>();

    RadioButton seoulButton1,seoulButton2,seoulButton3,
            busanButton1,busanButton2,
            gyeongjuButton1,gyeongjuButton2,gyeongjuButton3,
            jejuButton1,
            gangwonButton1,gangwonButton2,gangwonButton3;
    Button lngButton,courseButton;//언어 버튼, 코스 버튼;
    Intent intent;
    int checkNum;
    TextView seoulText,busanText,gyeongjuText,jejuText,gangwonText;
    LinearLayout seoulLayout,busanLayout, gyeongjuLayout, jejuLayout, gangwonLayout;
    //여기서부터
    private List<String> list;          // 데이터를 담을 리스트
    private EditText editSearch;        // 검색어를 입력할 Input 창터를 넣은 리스트변수

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageSetting();//이미지 등록
        imgOptimi();//좌우 크기 맞추기

        buttonSetting();//라디오 버튼 등록
        radioButtonSet();//라디오 버튼 이벤트 등록
        firstButton();//처음으로 눌러질 버튼

        lngButtonSet();//영어, 한국어 설정화면으로 이동
        courseButtonSet();//코스를 볼 수 있는 화면


        imageClick();//이미지 클릭시 이동

        layoutSetting();
        searchFunction();//지역 검색 함수;

        setText();//영어, 한국어 버전에 따라 텍스트 나누기
    }

    // 검색을 수행하는 메소드

    private void imageSetting(){
        seoulList1.add((ImageView)findViewById(R.id.seoulImg1_1));
        seoulList1.add((ImageView)findViewById(R.id.seoulImg1_2));
        seoulList1.add((ImageView)findViewById(R.id.seoulImg1_3));
        seoulList1.add((ImageView)findViewById(R.id.seoulImg1_4));
        seoulList1.add((ImageView)findViewById(R.id.seoulImg1_5));
        seoulList1.add((ImageView)findViewById(R.id.seoulImg1_6));
        seoulList1.add((ImageView)findViewById(R.id.seoulImg1_7));
        seoulList1.add((ImageView)findViewById(R.id.seoulImg1_8));
        seoulList1.add((ImageView)findViewById(R.id.seoulImg1_9));
        seoulList1.add((ImageView)findViewById(R.id.seoulImg1_10));
        seoulList1.add((ImageView)findViewById(R.id.seoulImg1_11));
        seoulList1.add((ImageView)findViewById(R.id.seoulImg1_12));
        seoulList1.add((ImageView)findViewById(R.id.seoulImg1_13));
        seoulList1.add((ImageView)findViewById(R.id.seoulImg1_14));
        seoulList1.add((ImageView)findViewById(R.id.seoulImg1_15));
        seoulList1.add((ImageView)findViewById(R.id.seoulImg1_16));
        seoulList1.add((ImageView)findViewById(R.id.seoulImg1_17));
        seoulList1.add((ImageView)findViewById(R.id.seoulImg1_18));
        seoulList1.add((ImageView)findViewById(R.id.seoulImg1_19));
        seoulList1.add((ImageView)findViewById(R.id.seoulImg1_20));
        seoulList1.add((ImageView)findViewById(R.id.seoulImg1_21));
        seoulList1.add((ImageView)findViewById(R.id.seoulImg1_22));
        seoulList1.add((ImageView)findViewById(R.id.seoulImg1_23));
        seoulList1.add((ImageView)findViewById(R.id.seoulImg1_24));
        seoulList1.add((ImageView)findViewById(R.id.seoulImg1_25));
        seoulList1.add((ImageView)findViewById(R.id.seoulImg1_26));
        seoulList1.add((ImageView)findViewById(R.id.seoulImg1_27));
        seoulList1.add((ImageView)findViewById(R.id.seoulImg1_28));
        seoulList1.add((ImageView)findViewById(R.id.seoulImg1_29));
        seoulList1.add((ImageView)findViewById(R.id.seoulImg1_30));
        seoulList1.add((ImageView)findViewById(R.id.seoulImg1_31));
        seoulList1.add((ImageView)findViewById(R.id.seoulImg1_32));
        seoulList2.add((ImageView)findViewById(R.id.seoulImg2_1));
        seoulList3.add((ImageView)findViewById(R.id.seoulImg3_1));
        seoulList3.add((ImageView)findViewById(R.id.seoulImg3_2));
        seoulList3.add((ImageView)findViewById(R.id.seoulImg3_3));
        seoulList3.add((ImageView)findViewById(R.id.seoulImg3_4));
        //3_5 삭제
        seoulList3.add((ImageView)findViewById(R.id.seoulImg3_6));
        seoulList3.add((ImageView)findViewById(R.id.seoulImg3_7));
        //3_9 삭제
        seoulList3.add((ImageView)findViewById(R.id.seoulImg3_9));
        busanList1.add((ImageView)findViewById(R.id.busanImg1_1));
        busanList1.add((ImageView)findViewById(R.id.busanImg1_2));
        busanList1.add((ImageView)findViewById(R.id.busanImg1_3));
        busanList1.add((ImageView)findViewById(R.id.busanImg1_4));
        busanList1.add((ImageView)findViewById(R.id.busanImg1_5));
        busanList2.add((ImageView)findViewById(R.id.busanImg2_1));
        busanList2.add((ImageView)findViewById(R.id.busanImg2_2));
        busanList2.add((ImageView)findViewById(R.id.busanImg2_3));
        busanList2.add((ImageView)findViewById(R.id.busanImg2_4));
        busanList2.add((ImageView)findViewById(R.id.busanImg2_5));
        busanList2.add((ImageView)findViewById(R.id.busanImg2_6));
        busanList2.add((ImageView)findViewById(R.id.busanImg2_7));
        gyeongjuList1.add((ImageView)findViewById(R.id.gyeongjuImg1_1));
        gyeongjuList1.add((ImageView)findViewById(R.id.gyeongjuImg1_2));
        gyeongjuList1.add((ImageView)findViewById(R.id.gyeongjuImg1_3));
        gyeongjuList2.add((ImageView)findViewById(R.id.gyeongjuImg2_1));
        gyeongjuList2.add((ImageView)findViewById(R.id.gyeongjuImg2_2));
        gyeongjuList2.add((ImageView)findViewById(R.id.gyeongjuImg2_3));
        gyeongjuList3.add((ImageView)findViewById(R.id.gyeongjuImg3_1));
        jejuList1.add((ImageView)findViewById(R.id.jejuImg1_1));
        jejuList1.add((ImageView)findViewById(R.id.jejuImg1_2));
        jejuList1.add((ImageView)findViewById(R.id.jejuImg1_3));
        jejuList1.add((ImageView)findViewById(R.id.jejuImg1_4));
        jejuList1.add((ImageView)findViewById(R.id.jejuImg1_5));
        jejuList1.add((ImageView)findViewById(R.id.jejuImg1_6));
        jejuList1.add((ImageView)findViewById(R.id.jejuImg1_7));
        jejuList1.add((ImageView)findViewById(R.id.jejuImg1_8));
        jejuList1.add((ImageView)findViewById(R.id.jejuImg1_9));
        jejuList1.add((ImageView)findViewById(R.id.jejuImg1_10));
        jejuList1.add((ImageView)findViewById(R.id.jejuImg1_11));
        jejuList1.add((ImageView)findViewById(R.id.jejuImg1_12));
        jejuList1.add((ImageView)findViewById(R.id.jejuImg1_13));
        jejuList1.add((ImageView)findViewById(R.id.jejuImg1_14));
        gangwonList1.add((ImageView)findViewById(R.id.gangwonImg1_1));
        gangwonList1.add((ImageView)findViewById(R.id.gangwonImg1_2));
        gangwonList1.add((ImageView)findViewById(R.id.gangwonImg1_3));
        gangwonList2.add((ImageView)findViewById(R.id.gangwonImg2_1));
        gangwonList3.add((ImageView)findViewById(R.id.gangwonImg3_1));
    }
    private void imgOptimi() {
        DisplayMetrics metrics = new DisplayMetrics();
        WindowManager windowManager = (WindowManager) getApplicationContext().getSystemService(Context.WINDOW_SERVICE);
        windowManager.getDefaultDisplay().getMetrics(metrics);
        LayoutParams params = (LayoutParams) seoulList1.get(0).getLayoutParams();
        params.height = metrics.heightPixels / 9;
        for(int i=0;i<seoulList1.size();i++){
            seoulList1.get(i).setLayoutParams(params);
        }
        for(int i=0;i<seoulList2.size();i++){
            seoulList2.get(i).setLayoutParams(params);
        }
        for(int i=0;i<seoulList3.size();i++){
            seoulList3.get(i).setLayoutParams(params);
        }
        for(int i=0;i<busanList1.size();i++){
            busanList1.get(i).setLayoutParams(params);
        }
        for(int i=0;i<busanList2.size();i++){
            busanList2.get(i).setLayoutParams(params);
        }
        for(int i=0;i<busanList3.size();i++){
            busanList3.get(i).setLayoutParams(params);
        }
        for(int i=0;i<gyeongjuList1.size();i++){
            gyeongjuList1.get(i).setLayoutParams(params);
        }
        for(int i=0;i<gyeongjuList2.size();i++){
            gyeongjuList2.get(i).setLayoutParams(params);
        }
        for(int i=0;i<gyeongjuList3.size();i++){
            gyeongjuList3.get(i).setLayoutParams(params);
        }
        for(int i=0;i<jejuList1.size();i++){
            jejuList1.get(i).setLayoutParams(params);
        }
        for(int i=0;i<jejuList2.size();i++){
            jejuList2.get(i).setLayoutParams(params);
        }
        for(int i=0;i<jejuList3.size();i++){
            jejuList3.get(i).setLayoutParams(params);
        }
        for(int i=0;i<gangwonList1.size();i++){
            gangwonList1.get(i).setLayoutParams(params);
        }
        for(int i=0;i<gangwonList2.size();i++){
            gangwonList2.get(i).setLayoutParams(params);
        }
        for(int i=0;i<gangwonList3.size();i++){
            gangwonList3.get(i).setLayoutParams(params);
        }

    }
    
    private void buttonSetting() {
        seoulButton1=findViewById(R.id.seoulButton1);
        seoulButton2=findViewById(R.id.seoulButton2);
        seoulButton3=findViewById(R.id.seoulButton3);
        busanButton1=findViewById(R.id.busanButton1);
        busanButton2=findViewById(R.id.busanButton2);
        gyeongjuButton1=findViewById(R.id.gyeongjuButton1);
        gyeongjuButton2=findViewById(R.id.gyeongjuButton2);
        gyeongjuButton3=findViewById(R.id.gyeongjuButton3);
        jejuButton1=findViewById(R.id.jejuButton1);
        gangwonButton1=findViewById(R.id.gangwonButton1);
        gangwonButton2=findViewById(R.id.gangwonButton2);
        gangwonButton3=findViewById(R.id.gangwonButton3);
    }
    private void radioButtonSet(){

        seoulButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for(int i=0;i<seoulList1.size();i++){
                    seoulList1.get(i).setVisibility(View.VISIBLE);
                }
                for(int i=0;i<seoulList2.size();i++){
                    seoulList2.get(i).setVisibility(View.GONE);
                }
                for(int i=0;i<seoulList3.size();i++){
                    seoulList3.get(i).setVisibility(View.GONE);
                }
            }
        });
        seoulButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for(int i=0;i<seoulList1.size();i++){
                    seoulList1.get(i).setVisibility(View.GONE);
                }
                for(int i=0;i<seoulList2.size();i++){
                    seoulList2.get(i).setVisibility(View.VISIBLE);
                }
                for(int i=0;i<seoulList3.size();i++){
                    seoulList3.get(i).setVisibility(View.GONE);
                }
            }
        });
        seoulButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for(int i=0;i<seoulList1.size();i++){
                    seoulList1.get(i).setVisibility(View.GONE);
                }
                for(int i=0;i<seoulList2.size();i++){
                    seoulList2.get(i).setVisibility(View.GONE);
                }
                for(int i=0;i<seoulList3.size();i++){
                    seoulList3.get(i).setVisibility(View.VISIBLE);
                }
            }
        });
        busanButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for(int i=0;i<busanList1.size();i++){
                    busanList1.get(i).setVisibility(View.VISIBLE);
                }
                for(int i=0;i<busanList2.size();i++){
                    busanList2.get(i).setVisibility(View.GONE);
                }
                for(int i=0;i<busanList3.size();i++){
                    busanList3.get(i).setVisibility(View.GONE);
                }
            }
        });
        busanButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for(int i=0;i<busanList1.size();i++){
                    busanList1.get(i).setVisibility(View.GONE);
                }
                for(int i=0;i<busanList2.size();i++){
                    busanList2.get(i).setVisibility(View.VISIBLE);
                }
                for(int i=0;i<busanList3.size();i++){
                    busanList3.get(i).setVisibility(View.GONE);
                }
            }
        });

        gyeongjuButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for(int i=0;i<gyeongjuList1.size();i++){
                    gyeongjuList1.get(i).setVisibility(View.VISIBLE);
                }
                for(int i=0;i<gyeongjuList2.size();i++){
                    gyeongjuList2.get(i).setVisibility(View.GONE);
                }
                for(int i=0;i<gyeongjuList3.size();i++){
                    gyeongjuList3.get(i).setVisibility(View.GONE);
                }
            }
        });
        gyeongjuButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for(int i=0;i<gyeongjuList1.size();i++){
                    gyeongjuList1.get(i).setVisibility(View.GONE);
                }
                for(int i=0;i<gyeongjuList2.size();i++){
                    gyeongjuList2.get(i).setVisibility(View.VISIBLE);
                }
                for(int i=0;i<gyeongjuList3.size();i++){
                    gyeongjuList3.get(i).setVisibility(View.GONE);
                }
            }
        });
        gyeongjuButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for(int i=0;i<gyeongjuList1.size();i++){
                    gyeongjuList1.get(i).setVisibility(View.GONE);
                }
                for(int i=0;i<gyeongjuList2.size();i++){
                    gyeongjuList2.get(i).setVisibility(View.GONE);
                }
                for(int i=0;i<gyeongjuList3.size();i++){
                    gyeongjuList3.get(i).setVisibility(View.VISIBLE);
                }
            }
        });
        jejuButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for(int i=0;i<jejuList1.size();i++){
                    jejuList1.get(i).setVisibility(View.VISIBLE);
                }
                for(int i=0;i<jejuList2.size();i++){
                    jejuList2.get(i).setVisibility(View.GONE);
                }
                for(int i=0;i<jejuList3.size();i++){
                    jejuList3.get(i).setVisibility(View.GONE);
                }
            }
        });


        gangwonButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for(int i=0;i<gangwonList1.size();i++){
                    gangwonList1.get(i).setVisibility(View.VISIBLE);
                }
                for(int i=0;i<gangwonList2.size();i++){
                    gangwonList2.get(i).setVisibility(View.GONE);
                }
                for(int i=0;i<gangwonList3.size();i++){
                    gangwonList3.get(i).setVisibility(View.GONE);
                }
            }
        });
        gangwonButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for(int i=0;i<gangwonList1.size();i++){
                    gangwonList1.get(i).setVisibility(View.GONE);
                }
                for(int i=0;i<gangwonList2.size();i++){
                    gangwonList2.get(i).setVisibility(View.VISIBLE);
                }
                for(int i=0;i<gangwonList3.size();i++){
                    gangwonList3.get(i).setVisibility(View.GONE);
                }
            }
        });
        gangwonButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for(int i=0;i<gangwonList1.size();i++){
                    gangwonList1.get(i).setVisibility(View.GONE);
                }
                for(int i=0;i<gangwonList2.size();i++){
                    gangwonList2.get(i).setVisibility(View.GONE);
                }
                for(int i=0;i<gangwonList3.size();i++){
                    gangwonList3.get(i).setVisibility(View.VISIBLE);
                }
            }
        });
    }
    private void firstButton() {
        seoulButton1.setChecked(true);
        for(int i=0;i<seoulList1.size();i++){
            seoulList1.get(i).setVisibility(View.VISIBLE);
        }
        busanButton1.setChecked(true);
        for(int i=0;i< busanList1.size();i++){
            busanList1.get(i).setVisibility(View.VISIBLE);
        }
        gyeongjuButton1.setChecked(true);
        for(int i=0;i< gyeongjuList1.size();i++){
            gyeongjuList1.get(i).setVisibility(View.VISIBLE);
        }
        jejuButton1.setChecked(true);
        for(int i=0;i< jejuList1.size();i++){
            jejuList1.get(i).setVisibility(View.VISIBLE);
        }
        gangwonButton1.setChecked(true);
        for(int i=0;i< gangwonList1.size();i++){
            gangwonList1.get(i).setVisibility(View.VISIBLE);
        }

    }
    
    private void lngButtonSet(){
        lngButton=findViewById(R.id.lngButton);//버튼등록
        lngButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent = new Intent(getApplicationContext(), Language.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
    }
    private void courseButtonSet(){
        courseButton=findViewById(R.id.courseButton);
        courseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent = new Intent(getApplicationContext(), Course.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
    }
    private void setText(){
        intent=getIntent();
        checkNum=intent.getIntExtra("language",checkNum);
        seoulText = findViewById(R.id.seoulText);
        busanText = findViewById(R.id.busanText);
        gyeongjuText = findViewById(R.id.gyeongjuText);
        jejuText= findViewById(R.id.jejuText);
        gangwonText = findViewById(R.id.gangwonText);

        if(checkNum==0) {
            seoulText.setText("Seoul");
            busanText.setText("Busan");
            gyeongjuText.setText("Gyeongju");
            jejuText.setText("Jeju");
            gangwonText.setText("Gangwon");

            seoulButton1.setText("tourist attraction");
            seoulButton2.setText("food");
            seoulButton3.setText("cultural properties");

            busanButton1.setText("tourist attraction");
            busanButton2.setText("food");

            gyeongjuButton1.setText("tourist attraction");
            gyeongjuButton2.setText("food");
            gyeongjuButton3.setText("cultural properties");

            jejuButton1.setText("tourist attraction");

            gangwonButton1.setText("tourist attraction");
            gangwonButton2.setText("food");
            gangwonButton3.setText("cultural properties");

            lngButton.setText("language");
            courseButton.setText("Course");

            editSearch.setHint("Please enter your search.");

        }
        if(checkNum==1) {
            seoulText.setText("서울");
            busanText.setText("부산");
            gyeongjuText.setText("경주");
            jejuText.setText("제주");
            gangwonText.setText("강원");

            seoulButton1.setText("관광지");
            seoulButton2.setText("음식");
            seoulButton3.setText("문화재");

            busanButton1.setText("관광지");
            busanButton2.setText("음식");

            gyeongjuButton1.setText("관광지");
            gyeongjuButton2.setText("음식");
            gyeongjuButton3.setText("문화재");

            jejuButton1.setText("관광지");

            gangwonButton1.setText("관광지");
            gangwonButton2.setText("음식");
            gangwonButton3.setText("문화재");

            lngButton.setText("언어");
            courseButton.setText("코스");

            editSearch.setHint("검색어를 입력하세요.");
        }

    }
   
    private void imageClick(){
        seoulList1.get(0).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Seoul1_1.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        seoulList1.get(1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Seoul1_2.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });

        seoulList1.get(2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Seoul1_3.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });

        seoulList1.get(3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Seoul1_4.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });

        seoulList1.get(4).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Seoul1_5.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });

        seoulList1.get(5).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Seoul1_6.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });

        seoulList1.get(6).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Seoul1_7.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });

        seoulList1.get(7).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Seoul1_8.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });

        seoulList1.get(8).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Seoul1_9.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });

        seoulList1.get(9).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Seoul1_10.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        seoulList1.get(10).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Seoul1_11.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        seoulList1.get(11).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Seoul1_12.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        seoulList1.get(12).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Seoul1_13.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        seoulList1.get(13).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Seoul1_14.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        seoulList1.get(14).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Seoul1_15.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        seoulList1.get(15).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Seoul1_16.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        seoulList1.get(16).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Seoul1_17.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        seoulList1.get(17).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Seoul1_18.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        seoulList1.get(18).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Seoul1_19.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        seoulList1.get(19).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Seoul1_20.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        seoulList1.get(20).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Seoul1_21.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        seoulList1.get(21).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Seoul1_22.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        seoulList1.get(22).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Seoul1_23.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        seoulList1.get(23).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Seoul1_24.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        seoulList1.get(24).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Seoul1_25.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        seoulList1.get(25).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Seoul1_26.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        seoulList1.get(26).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Seoul1_27.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        seoulList1.get(27).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Seoul1_28.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        seoulList1.get(28).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Seoul1_29.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        seoulList1.get(29).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Seoul1_30.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        seoulList1.get(30).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Seoul1_31.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        seoulList1.get(31).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Seoul1_32.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        seoulList2.get(0).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Seoul2_1.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        seoulList3.get(0).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Seoul3_1.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        seoulList3.get(1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Seoul3_2.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        seoulList3.get(2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Seoul3_3.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        seoulList3.get(3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Seoul3_4.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        seoulList3.get(4).setOnClickListener(new View.OnClickListener() {//3_5 삭제
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Seoul3_6.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        seoulList3.get(5).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Seoul3_7.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        seoulList3.get(6).setOnClickListener(new View.OnClickListener() {//3_8 삭제
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Seoul3_9.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        busanList1.get(0).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Busan1_1.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        busanList1.get(1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Busan1_2.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        busanList1.get(2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Busan1_3.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        busanList1.get(3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Busan1_4.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        busanList1.get(4).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Busan1_5.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        busanList2.get(0).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Busan2_1.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        busanList2.get(1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Busan2_2.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        busanList2.get(2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Busan2_3.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        busanList2.get(3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Busan2_4.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        busanList2.get(4).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Busan2_5.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        busanList2.get(5).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Busan2_6.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        busanList2.get(6).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Busan2_7.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        gyeongjuList1.get(0).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Gyeoungju1_1.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        gyeongjuList1.get(1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Gyeoungju1_2.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        gyeongjuList1.get(2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Gyeoungju1_3.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        gyeongjuList2.get(0).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Gyeoungju2_1.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        gyeongjuList2.get(1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Gyeoungju2_2.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        gyeongjuList2.get(2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Gyeoungju2_3.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        gyeongjuList3.get(0).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Gyeoungju3_1.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        jejuList1.get(0).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Jeju1_1.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        jejuList1.get(1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Jeju1_2.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        jejuList1.get(2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Jeju1_3.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        jejuList1.get(3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Jeju1_4.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        jejuList1.get(4).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Jeju1_5.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        jejuList1.get(5).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Jeju1_6.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        jejuList1.get(6).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Jeju1_7.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        jejuList1.get(7).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Jeju1_8.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        jejuList1.get(8).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Jeju1_9.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        jejuList1.get(9).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Jeju1_10.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        jejuList1.get(10).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Jeju1_11.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        jejuList1.get(11).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Jeju1_12.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        jejuList1.get(12).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Jeju1_13.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        jejuList1.get(13).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Jeju1_14.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        gangwonList1.get(0).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Gangwon1_1.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        gangwonList1.get(1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Gangwon1_2.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        gangwonList1.get(2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Gangwon1_3.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        gangwonList2.get(0).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Gangwon2_1.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
        gangwonList3.get(0).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), Gangwon3_1.class);
                intent.putExtra("language", checkNum);
                startActivity(intent);
            }
        });
    }

    private void layoutSetting(){
        seoulLayout=findViewById(R.id.seoulLayout);
        busanLayout=findViewById(R.id.busanLayout);
        gyeongjuLayout=findViewById(R.id.gyeongjuLayout);
        jejuLayout=findViewById(R.id.jejuLayout);
        gangwonLayout=findViewById(R.id.gangwonLayout);
    }
    private void searchFunction() {
        editSearch = (EditText) findViewById(R.id.editSearch);
        list = new ArrayList<String>();


        if(checkNum==0){
            settingList_eng();
        }
        if(checkNum==1){
            settingList_kor();
        }
        // 리스트의 모든 데이터를 arraylist에 복사한다.// list 복사본을 만든다.

        // input창에 검색어를 입력시 "addTextChangedListener" 이벤트 리스너를 정의한다.
        editSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                // input창에 문자를 입력할때마다 호출된다.
                // search 메소드를 호출한다.
                String text = editSearch.getText().toString();
                search(text);
            }
        });//텍스트창의 입력이 체인지 됐을때 발생하는 이벤트 리스너
    }
    public void search(String charText) {
        seoulLayout.setVisibility(View.GONE);
        busanLayout.setVisibility(View.GONE);
        gyeongjuLayout.setVisibility(View.GONE);
        jejuLayout.setVisibility(View.GONE);
        gangwonLayout.setVisibility(View.GONE);
        // 문자 입력이 없을때는 평소대로 보여줌.
        if (charText.length() == 0) {
            seoulLayout.setVisibility(View.VISIBLE);
            busanLayout.setVisibility(View.VISIBLE);
            gyeongjuLayout.setVisibility(View.VISIBLE);
            jejuLayout.setVisibility(View.VISIBLE);
            gangwonLayout.setVisibility(View.VISIBLE);
        }

        // 문자 입력을 할때..
        else
        {
            // 리스트의 모든 데이터를 검색한다.
            for(int i = 0;i < list.size(); i++)
            {
                // arraylist의 모든 데이터에 입력받은 단어(charText)가 포함되어 있으면 true를 반환한다.
                if (list.get(i).toLowerCase().contains(charText.toLowerCase()))
                {
                    if(i==0){
                        seoulLayout.setVisibility(View.VISIBLE);
                    }
                    else if(i==1){
                        busanLayout.setVisibility(View.VISIBLE);
                    }
                    else if(i==2){
                        gyeongjuLayout.setVisibility(View.VISIBLE);
                    }
                    else if(i==3){
                        jejuLayout.setVisibility(View.VISIBLE);
                    }
                    else if(i==4){
                        gangwonLayout.setVisibility(View.VISIBLE);
                    }
                }
            }
        }

    }//검색 메소드
    private void settingList_eng(){
        list.add("Seoul");
        list.add("Busan");
        list.add("Gyeoungju");
        list.add("Jeju");
        list.add("Gangwon");
    }// 검색에 사용될 데이터를 리스트에 추가한다
    private void settingList_kor(){
        list.add("서울");
        list.add("부산");
        list.add("경주");
        list.add("제주");
        list.add("강원");
    }// 검색에 사용될 데이터를 리스트에 추가한다
}

