package com.example.incourse;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.example.incourse.R;

public class TravelActivity extends AppCompatActivity {
    private TextView text1;
    Intent intent;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.travel_main);

        intent=getIntent();
        //text1 = findViewById(R.id.text1);
        //text1.setText(intent.getStringExtra("local"));
    }
}