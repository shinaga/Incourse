package com.example.incourse;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Gyeoungju3_1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gyeoungju3_1);
    }
}