package com.example.incourse;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

public class Gyeoungju1_3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent=getIntent();
        int checkNum=intent.getIntExtra("language",0);
        if(checkNum==1)setContentView(R.layout.activity_gyeoungju1_3kor);
        if(checkNum==0)setContentView(R.layout.activity_gyeoungju1_3);
    }
}