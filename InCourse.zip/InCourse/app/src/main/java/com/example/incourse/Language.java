package com.example.incourse;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Language extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_language);
    }
}