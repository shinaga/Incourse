package com.example.incourse;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

public class Seoul1_27 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent=getIntent();
        int checkNum=intent.getIntExtra("language",0);
        if(checkNum==0)setContentView(R.layout.activity_seoul1_27);
        if(checkNum==1)setContentView(R.layout.activity_seoul1_27kor);
    }
}