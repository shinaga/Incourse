package com.example.incourse;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Language extends AppCompatActivity {
    String lan;
    Intent intent;
    Button engButton,korButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_language);
        setButton();
        engButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lan="";//기본값
                Toast.makeText(getApplicationContext(),"change to english",Toast.LENGTH_SHORT).show();
            }
        });
        korButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lan="kor";
                Toast.makeText(getApplicationContext(),"한국어로 변경",Toast.LENGTH_SHORT).show();
            }
        });

    }
    @Override
    public void onBackPressed() {
        intent = new Intent(getApplicationContext(), MainActivity.class);
        intent.putExtra("language", lan);
        startActivity(intent);
    }
    private void setButton() {
        engButton=findViewById(R.id.engButton);
        korButton=findViewById(R.id.korButton);
    }


}